#include<iostream>

using namespace std;

int main(){

	cout << "Renee Thomas" << endl;
	cout << "CIS170C - Programming using C++\n";
	cout << "\n\n\nHello, world!\n\n";

	cin.ignore(2);

}