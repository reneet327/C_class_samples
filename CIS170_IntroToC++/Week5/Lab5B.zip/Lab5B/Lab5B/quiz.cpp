# include <iostream>
# include <iomanip>
# include <string>
# include <cctype> 

using namespace std;

int main()
{

	int n[10], i;
for(i = 0; i < 10; ++i)
     n[i] = i; 



	cin.ignore();
	
}
